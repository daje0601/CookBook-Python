import tweepy


def connect_api():
    """
    connect_api 함수는 tweepy 로 API 를 연결한 'api' 객체를 리턴합니다.

    Hint: api 객체는 tweepy.API 로 만들 수 있습니다.
    """

    api_key = "SvFSgQxeXSTIB9Xd4jSdB2L7v"
    api_key_secret = "gb7HogfzFldxG4lFlmXbgF5UpuOBwHhd3TrsZtU1dAGrw49gx0"
    access_token = "1372384598361960449-9q9R3Rw0F1WsG1HkFp6IQCaSjBwRU8"
    access_token_secret = "5Js2zj4kucA4WjnxD2tH5M512iW0VGstjB5wwYUCUtskF"

    auth = tweepy.OAuthHandler(api_key, api_key_secret)
    auth.set_access_token(access_token, access_token_secret)

    api = tweepy.API(auth)

    return api


def get_tweets(api, username):
    """
    'username' 이 주어지면 해당 유저의 트윗들을 가지고 올 수 있어야 합니다.
    각 트윗은 140 자 이상이어도 모든 내용을 가지고 올 수 있어야 합니다.

    Hint: 'tweet_mode' 에 대해서 알아보세요!
    """

    max_tweets = 150

    tweets = api.user_timeline(username, tweet_mode="extended")

    # tweets_list = [
    #     [
    #         tweet.text,
    #         tweet.created_at,
    #         tweet.id_str,
    #         tweet.user.screen_name,
    #         tweet.coordinates,
    #         tweet.place,
    #         tweet.retweet_count,
    #         tweet.favorite_count,
    #         tweet.lang,
    #         tweet.source,
    #         tweet.in_reply_to_status_id_str,
    #         tweet.in_reply_to_user_id_str,
    #         tweet.is_quote_status,
    #     ]
    #     for tweet in tweets
    # ]

    # # Creation of dataframe from tweets_list
    # # Add or remove columns as you remove tweet information
    # tweets_df = pd.DataFrame(tweets_list,columns=['Tweet Text', 'Tweet Datetime', 'Tweet Id', 'Twitter @ Name', 'Tweet Coordinates', 'Place Info', 'Retweets', 'Favorites', 'Language', 'Source', 'Replied Tweet Id', 'Replied Tweet User Id Str', 'Quote Status Bool'])

    # # Checks if there are coordinates attached to tweets, if so extracts them
    # tweets_df['Tweet Coordinates'] = tweets_df.apply(extract_coordinates,axis=1)

    # # Checks if there is place information available, if so extracts them
    # tweets_df['Place Info'] = tweets_df.apply(extract_place,axis=1)

    return tweets
