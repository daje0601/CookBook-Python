import requests
import json

API_KEY = "5beedf974be57550d9cf7d27721057c3"


def get_city_data(city_name):

    API_URL = (
        f"https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={API_KEY}"
    )

    raw_data = requests.get(API_URL)
    parsed_data = json.loads(raw_data.text)

    current_weather = parsed_data

    return current_weather


def get_weather_description(json_data):

    weather_description = json_data["weather"][0]["description"]

    return weather_description


def get_minimum_temp(json_data):
    """
    get_minimum_temp 함수는 최저 온도를 섭씨(℃) 단위로 리턴해야 합니다.

    파라미터:
        - json_data: OpenWeather API 로부터 받아온 JSON 데이터입니다.

    리턴:
        - 온도 정보: 주어진 JSON 데이터에서 숫자(int) 인 온도 정보를 리턴합니다.
    """

    temp_min = int(json_data["main"]["temp_min"] - 273.15)

    return temp_min
