from random import randint

"""
Part 1

클래스에 대해서 알아봅니다.

Product 클래스와 Tea 클래스를 만들어 봅니다.
"""


class Product:
    def __init__(
        self,
        name,
        price=30,
        size=20,
        warmness=0.5,
        sweetness=0.5,
        identifier=randint(1000000, 9999999),
    ):
        self.name = name
        self.price = price
        self.size = size
        self.warmness = warmness
        self.sweetness = sweetness
        self.identifier = identifier

    def sellability(self):
        sellability = self.size / self.price

        if sellability < 0.5:
            return "Not so sellable..."
        elif sellability < 1.0:
            return "Kinda sellable."
        else:
            return "Very sellable!"

    def calory(self):
        cal_calory = self.size * self.sweetness

        if cal_calory < 10:
            return "...it's light"
        elif cal_calory < 50:
            return "It's adequate."
        else:
            return "It's really heavy..!!"


class Tea(Product):
    def __init__(
        self,
        name,
        price=30,
        size=10,
        warmness=0.5,
        sweetness=0.5,
        identifier=randint(1000000, 9999999),
    ):
        super().__init__(
            name,
            price=30,
            size=10,
            warmness=0.5,
            sweetness=0.5,
            identifier=randint(1000000, 9999999),
        )

    def calory(self):
        redefine_calory = "...it's a tea. Only a few calories"
        return redefine_calory

    def drink(self):
        if self.warmness < 0.5:
            return "it's too cold..."
        elif 0.5 <= self.warmness < 1.0:
            return "Oh, it's warm!"
        else:
            return "It's too hot!!"