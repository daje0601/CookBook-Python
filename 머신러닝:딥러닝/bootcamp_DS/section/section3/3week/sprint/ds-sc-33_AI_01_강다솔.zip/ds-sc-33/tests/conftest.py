import os
import pytest
from flask_sqlalchemy import SQLAlchemy
from src import need_air as na

TEST_DB_NAME = os.path.join(os.getcwd(), 'test_db.sqlite3')

@pytest.fixture
def single_data():
    return {
        'datetime': '2020-11-19T02:00:00Z',
        'value': 10.0
    }


@pytest.fixture
def get_app_db():
    return na.app, na.db


@pytest.fixture
def get_test_app_db():
    app = na.app
    app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{TEST_DB_NAME}"
    db = SQLAlchemy(app)

    return app, db


@pytest.fixture
def remove_test_db_file():
    def remove_func():
        cwd = os.path.dirname(__file__)
        try:
            os.remove(TEST_DB_NAME)
        except:
            print("File doesn't exist")

    return remove_func

@pytest.fixture
def get_results_func():
    def return_func():
        return na.get_results

    return return_func
