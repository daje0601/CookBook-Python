# Sprint Challenge 31x

## Web Application

이번 스프린트 챌린지에선 공기질에 관한 데이터를 보여주는 Flask 기반 웹 어플리케이션을 만들게 됩니다. 이번 챌린지에선 칠레에 있는 Los Angeles 한 곳의 데이터만 가져오도록 하겠습니다.

여러분이 이 스프린트 챌린지의 기본 조건을 달성하는데 필요한 라이브러리는 다음과 같습니다.

1) `flask`,`flask-sqlalchemy`: 웹 어플리케이션 및 데이터 모델들을 만드는데 사용합니다

2) `openaq`: OpenAQ API 에 접근할 수 있는 패키지입니다.

3) `need_air.py` 파일에서 작업을 합니다.

> 파트가 나뉘어져 있지만 반드시 숫자대로 진행하지 않으셔도 됩니다!

# Part 1 Flask

## 1.1 초기 설정을 완성합니다.

- db 를 flask 어플리케이션과 연결해줍니다.

## 1.2 `index` 함수를 완성합니다.

루트 엔드포인트 ('/') 에 접근 시 데이터베이스에 저장된 레코드 중에서 `value` 값이 10 이 넘는 레코드들을 필터해서 리턴합니다.

- Hint: list 는 리턴할 수 없지만 str은 리턴할 수 있습니다

## 1.3 `refresh` 함수를 완성합니다.

새로고침 엔드포인트 ('/refresh') 에 접근 시 다음을 실행합니다:
- 기존 데이터베이스 삭제
- 새로운 데이터베이스 생성
- 1.4번의 `get_results` 함수를 이용해서 데이터베이스에 데이터를 추가

## 1.4 **get_results** 함수를 만듭니다.

> 함수는 아래의 코드에 있는 body를 활용하여 `(utc_datetime, value)`로 이루어진 tuple들의 리스트를 반환해야합니다.

 ```python
_, body = api.measurements(city='Los Angeles', parameter='pm25')
 ```

- Hint: 다음의 링크를 들어가면 `body`에 들어가는 정보를 확인 할 수 있습니다 (https://api.openaq.org/v1/measurements?city=Los%20Angeles&parameter=pm25)
- 필요한 datetime과 value는 중첩 된 dictionary 안에 있습니다, 어떻게 필요한 데이터를 빼올 수 있을지 여러가지 시도를 해보시길 바랍니다.

# Part 2 Database

## 2.1 `Record` 테이블을 생성합니다.

필드 목록 :
- id : Integer 이며 기본키입니다.
- datetime : 길이가 25인 String(Varchar) 입니다.
- value : Float 이며 Null 일 수 없습니다.


## 2.2 `Record` 테이블의 `__repr__` 메소드를 완성합니다.

- 저장된 레코드의 Time 과 Value 를 보여주어야 합니다.
- 예시 : `< Time 2020-11-18T23:00:00Z --- Value 13.0 >`

- Hint(2가지 방법)
1. `.format` 을 활용해서 형식을 만들어보세요
2. `f-string`을 활용해서 형식을 만들어보세요
