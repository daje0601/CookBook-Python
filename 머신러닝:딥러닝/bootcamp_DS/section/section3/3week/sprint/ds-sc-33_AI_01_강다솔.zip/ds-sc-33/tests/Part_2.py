from src.need_air import Record


def test_fieldname_value():
    assert str(Record.value.type) == 'FLOAT'
    assert Record.value.nullable == False


def test_fieldname_datetime():
    assert str(Record.datetime.type) == 'VARCHAR(25)'


def test_fieldname_id():
    assert str(Record.id.type) == 'INTEGER'
    assert Record.id.primary_key == True


def test_new_record(single_data):
    record = Record(datetime=single_data['datetime'],
                    value=single_data['value'])

    assert record.datetime == single_data['datetime']
    assert record.value == single_data['value']


def test_record_repr(single_data):
    record = Record(datetime=single_data['datetime'],
                    value=single_data['value'])

    expected_ans = f"< Time {single_data['datetime']} --- Value {single_data['value']} >"

    assert str(record) == expected_ans
