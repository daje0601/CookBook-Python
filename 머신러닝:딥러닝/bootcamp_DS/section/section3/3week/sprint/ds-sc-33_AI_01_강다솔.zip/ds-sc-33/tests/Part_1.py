def test_index(get_app_db):
    app, _ = get_app_db

    with app.test_client() as test_client:
        test_client.get('/refresh')
        response = test_client.get('/')
        assert response.status_code == 200


def test_route_refresh(get_test_app_db, remove_test_db_file):
    app, _ = get_test_app_db

    with app.test_client() as test_client:
        response = test_client.get('/refresh')
        assert response.status_code == 200
        remove_test_db_file()


def test_get_results(get_results_func):
    func = get_results_func()
    results = func()
    assert type(results) == list
    assert len(results) >= 1
    for item in results:
        assert type(item) == tuple
