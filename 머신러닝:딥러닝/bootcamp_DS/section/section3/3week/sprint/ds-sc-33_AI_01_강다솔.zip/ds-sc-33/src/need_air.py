from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from openaq import OpenAQ

# OpenAQ 를 활용하기 위한 설정입니다. (수정 X )
api = OpenAQ()

# app 관련 설정입니다. (수정 X )
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///db.sqlite3"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# TODO Database(flask_sqlalchemy)를 사용하기 위해 초기 설정을 해줍니다.

db = SQLAlchemy(app)


@app.route("/")
def index():

    # TODO Recode에서 value 값이 10 이상인 값들만 필터해서(검색해서) results 에 저장합니다.
    # TODO results를 문자열 형태로 리턴합니다.

    results = Record.query.filter(Record.value >= 10).all()

    return str(results)


@app.route("/refresh")
def refresh():
    # TODO 데이터베이스의 기존 데이터를 지우고 새로 생성합니다.
    # TODO get_results 함수에서부터 받은 결과들을 Record 테이블에 저장합니다.
    # TODO Record 테이블의 변경사항을 데이터베이스에 저장합니다.
    # TODO 'Data refreshed!' 문자열을 리턴합니다.
    db.drop_all()
    db.create_all()
    db.session.commit()
    return "Data refreshed!"


def get_results():
    # OpenAQ에서 데이터를 불러옵니다. (아래 문장은 수정 X)
    _, body = api.measurements(city="Los Angeles", parameter="pm25")
    # TODO datetime 와 value 를 튜플 형태로 results 에 추가합니다.
    # Hint: 다음의 링크를 들어가면 body에 들어가는 정보를 확인 할 수 있습니다
    # https://api.openaq.org/v1/measurements?city=Los%20Angeles&parameter=pm25
    # TODO results 리스트를 리턴합니다.
    result_tuple = []
    for json_data in body["results"]:
        datetime = json_data["date"]["utc"]
        value = value = json_data["value"]
        result = (datetime, value)
        result_tuple.append(result)

    return result_tuple


# 이녀석은 왜 하단에 있는가?
class Record(db.Model):
    # TODO 테이블 이름을 record 로 설정해줍니다.
    # TODO 각 필드들에 대한 설정을 해줍니다.
    # TODO __repr__ 함수를 완성합니다.
    # 예시 : < Time 2020-11-18T23:00:00Z --- Value 13.0 >
    # 예시 : < Time ~~~~ --- Value ~~~ >
    id = db.Column(db.Integer, primary_key=True)
    datetime = db.Column(db.String(25))
    value = db.Column(db.Float, nullable=False)

    def __repr__(self):
        return "< Time {} --- Value {} >".format(self.datetime, self.value)

    # pass


# 필요시에 app.run 을 이용해 로컬에서 실험합니다.
# if __name__ == "__main__":
# app.run(debug=True)
